---@type table<string, fun(self: Client, data: any)>
fk.client_callback = {}

dofile "ltk/client/client.lua"

-- 总而言之就是会让roomScene.state变为responding或者playing的状态
local pattern_refresh_commands = {
  "PlayCard",
  "AskForUseActiveSkill",
  "AskForUseCard",
  "AskForResponseCard",
}

-- 传了个string且不知道为什么不走cbor.decode的
local no_decode_commands = {
  "ErrorMsg",
  "ErrorDlg",
  "Heartbeat",
  "ServerMessage",

  "UpdateAvatar",
  "UpdatePassword",
}

ClientCallback = function(_self, command, jsonData, isRequest)
  local self = ClientInstance
  -- Invitations belong to the live account session, never to a replay.
  local room_invite_message = command == "RoomInviteSettings" or command == "RoomInvitePlayers" or
    command == "RoomInviteResult" or command == "RoomInvitation" or command == "RoomInvitationClosed"
  if self.replaying and room_invite_message then return end
  if self.recording and not room_invite_message then
    table.insert(self.record, {math.floor(os.getms() / 1000), isRequest, command, jsonData})
  end

  -- CBOR调试中。。。
  -- print(command, jsonData:gsub(".", function(c) return ("%02x"):format(c:byte()) end))

  local cb = self.callbacks[command] or fk.client_callback[command]
  local data
  if table.contains(no_decode_commands, command) then
    data = jsonData
  else
    data = cbor.decode(jsonData)
  end

  -- TQS_HEG_CARD_WIRE_NEGOTIATION: this is the only packet allowed to move
  -- the client from legacy IDs to v1. It is deliberately handled before all
  -- card-bearing decoders and is never forwarded to the UI as an ordinary
  -- command.
  if command == "CardWireNegotiated" then
    assert(not isRequest, "card wire negotiation must be a notification")
    require("ltk.client.card_wire_negotiation").receive(self, data)
    return
  end

  -- TQS_HEG_CARD_WIRE_CLIENT_SNAPSHOT: localize a complete physical
  -- Reconnect/Observe snapshot before legacy Client/CardManager deserialize.
  local cardWireSnapshot = false
  if self.card_wire_version == 1 and
      (command == "Reconnect" or command == "Observe") and
      type(data) == "table" and data.cardWireVersion == 1 then
    data = require("ltk.client.card_wire_snapshots").receive(self, data)
    cardWireSnapshot = true
  end
  -- TQS_HEG_CARD_WIRE_CLIENT_PUBLIC: reconstruct only audited public
  -- card descriptors before the legacy ShowVirtualCard/GameLog callbacks.
  if self.card_wire_version == 1 and
      (command == "ShowVirtualCard" or command == "GameLog") and
      type(data) == "table" and data.cardWireVersion == 1 then
    data = require("ltk.client.card_wire_public").receive(self, command, data)
  end
  -- TQS_HEG_CARD_WIRE_CLIENT_METADATA: localize audited card metadata/AG
  -- envelopes before legacy callbacks or the UI see physical references.
  if self.card_wire_version == 1 and
      (command == "SetCardFootnote" or command == "SetCardVirtName" or
       command == "FilterCard" or command == "SetPlayerHandCards" or
       command == "AddVirtualEquip" or command == "RemoveVirtualEquip" or
       command == "FillAG" or command == "TakeAG") then
    assert(type(data) == "table" and data.cardWireVersion == 1,
      "v1 card metadata/AG requires an explicit envelope")
    local localized, deliver = require("ltk.client.card_wire_metadata").receive(
      self, command, data)
    if not deliver then return end
    data = localized
  end

  -- TQS_HEG_CARD_WIRE_CLIENT_REQUEST: unwrap only an explicit v1 request
  -- envelope. A missing/legacy payload is never silently interpreted as v1.
  if self.card_wire_version == 1 and type(data) == "table" and
      data.cardWireVersion == 1 then
    data = require("ltk.client.card_wire_requests").receive(self, command, data)
  end

  if table.contains(pattern_refresh_commands, command) then
    Fk.currentResponsePattern = nil
    Fk.currentResponseReason = nil
  end

  if (type(cb) == "function") then
    if command:startsWith("AskFor") or command == "PlayCard" then
      self:notifyUI("CancelRequest") -- 确保变成notactive 防止卡双active 权宜之计
    end
    if cardWireSnapshot then
      require("ltk.client.card_wire_snapshots").dispatch(self, cb, data)
    else
      cb(self, data)
    end
  else
    self:notifyUI(command, data)
  end
end

-- Create ClientInstance (used by Lua)
-- Let Cpp call this function to create
function CreateLuaClient(cpp_client)
  ClientInstance = Client:new(cpp_client)
end

dofile "lua/client/client_util.lua"
dofile "lua/client/i18n/init.lua"

if FileIO.pwd():endsWith("packages/freekill-core") then
  FileIO.cd("../..")
end

-- 此为client.lua的末尾，客户端VM等待调试器
-- 由于可能的bug，暂时不开启
if fk._VscodeDbgEnabled == "client" then
  fk._VscodeDbgWait(5927)
end
