---@class ClientBase : Base.RoomBase
---@field public client fk.Client
---@field public clientplayer_klass any
---@field public observing boolean 客户端是否在旁观
---@field public observer_setup_data any 我这个旁观者本人的实际setup信息
---@field public observer_player any 旁观者本人的独立身份（Lua Player，本人 id 常驻 cpp map；仅对局旁观时建立）
---@field public replaying boolean 客户端是否在重放
---@field public replaying_show boolean 重放时是否要看到全部牌
---@field public record any
---@field public callbacks { [string|integer]: fun(self, data) }
---@field public disabled_packs string[] FIXME:拓展包设置依赖这玩意，看看能不能把他赶出通用Mixin
---@field public disabled_generals string[]
local ClientBase = {}

function ClientBase:initialize(_client)
  self.client = _client
  self.recording = false
  self.callbacks = {}
  self.disabled_packs = {}
  self.disabled_generals = {}
  ------------------------
  self:addCallback("NetworkDelayTest", self.sendSetupPacket)
  self:addCallback("Setup", self.setup)
  self:addCallback("Heartbeat", self.heartbeat)

  self:addCallback("EnterRoom", self.enterRoom, true)
  self:addCallback("ChangeRoom", self.changeRoom, true)
  self:addCallback("EnterLobby", self.quitRoom, true)
  self:addCallback("AddPlayer", self.addPlayer)
  self:addCallback("RemovePlayer", self.removePlayer)
  self:addCallback("AddObserver", self.addObserver, true)
  self:addCallback("RemoveObserver", self.removeObserver, true)
  self:addCallback("SwitchToObserver", self.switchToObserver, true)
  self:addCallback("SwitchToPlayer", self.switchToPlayer, true)
  self:addCallback("UpdateGameData", self.updateGameData, true)
  self:addCallback("AddTotalGameTime", self.addTotalGameTime)
  self:addCallback("NetStateChanged", self.changeNetState, true)
  self:addCallback("ReadyChanged", self.changeReady, true)
  self:addCallback("RoomOwner", self.changeRoomOwner, true)
  self:addCallback("Chat", self.chat)

  self:addCallback("StartGame", self.startGame)

  self:addCallback("ArrangeSeats", self.arrangeSeats)
  self:addCallback("SetPlayerMark", self.handleSetPlayerMark)
  self:addCallback("SetBanner", self.handleSetBanner)
  self:addCallback("Reconnect", self.reconnect)
  self:addCallback("Observe", self.observe)

  self:addCallback("PropertyUpdate", self.propertyUpdate)
  self:addCallback("GameLog", self.appendLog)

  self:addCallback("AddNpc", self.addNpc)

  self:addCallback("GameOver", self.gameOver)
end

---@param func fun(self, data)
---@param ui_func boolean?
function ClientBase:addCallback(command, func, ui_func)
  self.callbacks[command] = ui_func and function(s, data)
    func(s, data)
    self.client:notifyUI(command, data)
  end or func
end

function ClientBase:notifyUI(command, data)
  self.client:notifyUI(command, data)
end

function ClientBase:startRecording()
  if self.recording then return end
  if self.replaying then return end
  self.record = {
    fk.FK_VER,
    os.date("%Y%m%d%H%M%S"),
    self.enter_room_data,
    cbor.encode { Self.id, Self.player:getScreenName(), Self.player:getAvatar() },
    "",       -- 由于C++写翻车，此条空出来
    "normal", -- 表示本录像是正常全流程，还是重连，还是旁观
    -- RESERVED
    "",
    "",
    "",
    "",
  }
  for _, p in ipairs(self.players) do
    if p.id ~= Self.id then
      table.insert(self.record, {
        math.floor(os.getms() / 1000),
        false,
        "AddPlayer",
        cbor.encode {
          p.player:getId(),
          p.player:getScreenName(),
          p.player:getAvatar(),
          true,
          p.player:getTotalGameTime(),
        },
      })
    end
  end
  self.recording = true
end

function ClientBase:stopRecording(jsonData)
  if not self.recording then return end
  self.record[2] = table.concat({
    self.record[2],
    Self.player:getScreenName():gsub("%.", "%%2e"),
    self:getSettings('gameMode'),
    Self.general or "",
    Self.role or "unknown",
    jsonData,
  }, ".")
  self.recording = false
end

-- callbacks

function ClientBase:sendSetupPacket(data)
  self.client:sendSetupPacket(data)
end

function ClientBase:setup(data)
  local id, name, avatar, msec = data[1], data[2], data[3], data[4]
  local self_player = self.client:getSelf()
  self_player:setId(id)
  self_player:setScreenName(name)
  self_player:setAvatar(avatar)
  if data[6] then
    self_player:setGameData(table.unpack(data[6]))
  end
  Self = self:createPlayer(self_player)
  self.players = { Self }
  if msec then
    self.client:setupServerLag(msec)
  end
end

function ClientBase:heartbeat()
  self.client:notifyServer("Heartbeat", "")
end

function ClientBase:updateDisabled(data)
  local disabled_packs = data.disabledPack or {}

  table.insertTableIfNeed(
    disabled_packs,
    Fk.game_mode_disabled[data.gameMode] or Util.DummyTable
  )
  data.disabledPack = disabled_packs

  self.disabled_packs = disabled_packs
  self.disabled_generals = data.disabledGenerals or {}
end

function ClientBase:enterRoom(_data)
  local cardWireSnapshot = self._card_wire_snapshot
  self._card_wire_snapshot = nil
  local data = _data[3]

  -- FIXME: 需要改Qml
  local ob = self.observing
  local obdata = self.observer_setup_data
  local replaying = self.replaying
  local showcards = self.replaying_show
  local recording = self.recording
  -- FIXME: 写出record的时候就该好好反省一下哪里设计出问题了
  local record = self.record

  local client_klass = Fk:getBoardGame(data.gameMode).client_klass
  ClientInstance = client_klass:new(self.client)
  self = ClientInstance
  if cardWireSnapshot then
    assert(data.gameMode == "new_heg_mode" and cardWireSnapshot.refs,
      "snapshot state requires the validated Hegemony room")
    self.card_wire_version = 1
    self.card_wire_protocol = cardWireSnapshot.protocol
    self.card_wire_negotiated = true
    self.card_wire_refs = cardWireSnapshot.refs
  end
  Self = self:createPlayer(self.client:getSelf())

  self.observing = ob
  self.observer_setup_data = obdata
  self.replaying = replaying
  self.replaying_show = showcards
  self.recording = recording -- 重连/旁观的录像后面那段EnterRoom会触发该函数
  self.record = record

  -- FIXME: 应该在C++中修改，这种改法错大发了
  -- FIXME: C++中加入房间时需要把Self也纳入players列表
  -- FIXME: 经典甩锅v0.6
  -- FIXME: 这几句是不是有内存泄漏啊
  local sp = Self.player
  local new_sp = self.client:addPlayer(sp:getId(), sp:getScreenName(), sp:getAvatar())
  -- 旁观别把旁观的总时长加到玩家上了p self 顶替成 observee，但其 totalGameTime 仍是旁观者本人的；
  -- 这里不能复制它，否则 observee 的时长会被污染成旁观者时长（UI 等级框显示错）。
  -- observe() 会把 observee 的真实总时长放进 observer_setup_data[5]，创建即用正确基线。
  if self.observer_setup_data and self.observer_setup_data[5] then
    new_sp:addTotalGameTime(self.observer_setup_data[5])
  else
    new_sp:addTotalGameTime(sp:getTotalGameTime())
  end
  local gameData = sp:getGameData()
  new_sp:setGameData(gameData:at(0), gameData:at(1), gameData:at(2))
  Self.player = new_sp

  -- 旁观者在游戏开始前进入
  if data.isObserver and data._players then
    local players = {}
    for _, tab in ipairs(data._players or {}) do
      local id, name, avatar, ready, gameTime, owner, gameData = table.unpack(tab)
      local cp = self.client:addPlayer(id, name, avatar)
      cp:addTotalGameTime(gameTime)
      if gameData then
        cp:setGameData(table.unpack(gameData))
      end
      local lp = self:createPlayer(cp)
      table.insert(players, lp)
    end
    self.players = players
    self.alive_players = table.simpleClone(players)
  else
    self.players = { Self }
    self.alive_players = { Self }
  end

  self:updateDisabled(data)

  self.enter_room_data = cbor.encode(_data);
  -- 补一个，防止爆炸
  if self.recording then
    self.record[3] = self.enter_room_data
  end
  self.capacity = _data[1]
  self.timeout = _data[2]
  self.settings = data

  -- 旁观者在游戏开始前进入时，从 EnterRoom 数据填充旁观者列表（含自己）
  if data.isObserver and data._observers then
    self.observers = {}
    local function fakeObs(id, name, avatar, gameTime)
      local player = {
        getId = function() return id end,
        getScreenName = function() return name end,
        getAvatar = function() return avatar end,
        getState = function() return fk.Player_Online end,
        getTotalGameTime = function() return gameTime end,
      }
      return { 0, player, id }
    end
    for _, o in ipairs(data._observers or {}) do
      table.insert(self.observers, fakeObs(o[1], o[2], o[3], o[5]))
    end
  end
end

function ClientBase:changeRoom(_data)
  -- 怎么data[1]是个name，扬了，主要c++中偷懒了
  table.remove(_data, 1)

  local data = _data[3]

  -- 玩家还是同一批人，只是配置信息改变，所以这里也简单点
  -- 不过Client还是必须重新创建

  -- FIXME: 需要改Qml
  local ob = self.observing
  local obdata = self.observer_setup_data
  local replaying = self.replaying
  local showcards = self.replaying_show
  local recording = self.recording
  -- FIXME: 写出record的时候就该好好反省一下哪里设计出问题了
  local record = self.record

  local old_players = self.players
  local old_observers = self.observers or {}
  local old_self = Self
  local old_self_id = old_self and old_self.id

  local client_klass = Fk:getBoardGame(data.gameMode).client_klass
  ClientInstance = client_klass:new(self.client)
  self = ClientInstance

  self.observing = ob
  self.observer_setup_data = obdata
  self.replaying = replaying
  self.replaying_show = showcards
  self.recording = recording -- 重连/旁观的录像后面那段EnterRoom会触发该函数
  self.record = record

  local new_players = table.map(old_players, function(p)
    local pl = self:createPlayer(p.player)
    pl.owner = p.owner
    pl.ready = p.ready
    return pl
  end)
  self.players = new_players
  self.alive_players = table.simpleClone(new_players)
  self.observers = old_observers
  if old_self_id then
    -- A pre-game observer is intentionally absent from players. Keep its
    -- client identity when rebuilding the room for a settings change.
    Self = self:getPlayerById(old_self_id) or old_self
  end

  data.isObserver = self.observing == true
  data._players = table.map(self.players, function(p)
    local cp = p.player
    local gameData = {}
    for _, value in fk.qlist(cp:getGameData()) do
      table.insert(gameData, value)
    end
    return {
      cp:getId(), cp:getScreenName(), cp:getAvatar(),
      p.ready == true, cp:getTotalGameTime(), p.owner == true, gameData,
    }
  end)
  data._observers = table.map(self.observers, function(t)
    local p = t[2]
    return { t[3], p:getScreenName(), p:getAvatar(), false, p:getTotalGameTime() }
  end)

  self:updateDisabled(data)

  self.enter_room_data = cbor.encode(_data);

  -- 补一个，防止爆炸
  if self.recording then
    self.record[3] = self.enter_room_data
  end
  self.capacity = _data[1]
  self.timeout = _data[2]
  self.settings = data
end

function ClientBase:quitRoom()
  self:stopRecording("")
end

---@param played_time? integer @ 对局已进行时长（秒）
function ClientBase:startGame(data, played_time)
  if self.gameStarted then return end
  if not self.replaying then
    self:startRecording()
  end

  -- FIXME 这是个给cpp擦屁股的行为 cpp中播放录像会立刻播一句StartGame
  -- FIXME 而新UI中必须先AddPlayer再StartGame（进入页面）
  -- FIXME 为此只好延迟一会 等全addPlayer齐了再StartGame
  -- FIXME AddPlayer中有一段同理
  if self.replaying and self.capacity > 1 and #self.players == 1 then
    return
  end

  self.gameStarted = true
  self.gameStartTime = os.time() - math.max(0, played_time or 0)

  local players = {}

  self:notifyUI("StartGame", data)
end

function ClientBase:updateGameData(data)
  local player, total, win, run = data[1], data[2], data[3], data[4]
  player = self:getPlayerById(player)
  if player then
    player.player:setGameData(total, win, run)
  end
end

function ClientBase:addTotalGameTime(data)
  local player, time = data[1], data[2]
  player = self:getPlayerById(player)
  if player then
    player.player:addTotalGameTime(time)
    if player == Self then
      self:notifyUI("AddTotalGameTime", data)
    end
  end
end

function ClientBase:changeNetState(data)
  local pid, state = data[1], data[2]
  local p = self:getPlayerById(pid) --[[@as ClientPlayer]]
  if not p then return end

  -- 被蠢到了，怎么没给Lua开放setStateString
  if state == "online" then
    p.player:setState(fk.Player_Online)
  elseif state == "trust" then
    p.player:setState(fk.Player_Trust)
  elseif state == "run" then
    p.player:setState(fk.Player_Run)
  elseif state == "robot" then
    p.player:setState(fk.Player_Robot)
  elseif state == "offline" then
    p.player:setState(fk.Player_Offline)
  else
    p.player:setState(fk.Player_Invalid)
  end
end

function ClientBase:changeReady(data)
  local pid, ready = data[1], data[2]
  local p = self:getPlayerById(pid) --[[@as ClientPlayer]]
  if not p then return end

  p.ready = ready
end

function ClientBase:changeRoomOwner(data)
  local pid = data[1]
  for _, p in ipairs(self.players) do
    p.owner = p.id == pid
  end
end

function ClientBase:createPlayer(_player)
  return self.clientplayer_klass:new(_player)
end

function ClientBase:addPlayer(data)
  local id, name, avatar, ready, time = data[1], data[2], data[3], data[4], data[5]
  local player = self.client:addPlayer(id, name, avatar)
  player:addTotalGameTime(time or 0)
  if data[6] then
    player:setGameData(table.unpack(data[6]))
  end
  -- cpp连这个都没做？
  if id > 0 then
    player:setState(fk.Player_Online)
  else
    player:setState(fk.Player_Robot)
  end
  local p = self:createPlayer(player)
  p.ready = ready
  table.insert(self.players, p)
  self:notifyUI("AddPlayer", data)

  -- FIXME 详见StartGame
  if self.replaying and #self.players == self.capacity then
    self:startGame(nil)
  end
end

function ClientBase:removePlayer(data)
  -- jsonData: [ int id ]
  local id = data[1]
  for _, p in ipairs(self.players) do
    if p.player:getId() == id then
      table.removeOne(self.players, p)
      break
    end
  end

  if id ~= Self.id then
    self.client:removePlayer(id)
    self:notifyUI("RemovePlayer", data)
  end
end

function ClientBase:addObserver(data)
  local id, name, avatar, gameTime = data[1], data[2], data[3], data[5]
  -- 防重：同一旁观者只保留一条。服务器广播/摘要可能与本地的 ensureObserverIdentity 重复下发本人
  for _, o in ipairs(self.observers or {}) do
    if o[3] == id then
      return
    end
  end
  local player = {
    getId = function() return id end,
    getScreenName = function() return name end,
    getAvatar = function() return avatar end,
    getState = function() return fk.Player_Online end,
    getTotalGameTime = function() return gameTime end,
  }
  table.insert(self.observers, { 0, player, id })
  -- self:notifyUI("ServerMessage", string.format(Fk:translate("$AddObserver"), name))
end

function ClientBase:removeObserver(data)
  local id = data[1]
  for i, p in ipairs(self.observers) do
    if p[3] == id then
      table.remove(self.observers, i)
      -- self:notifyUI("ServerMessage", string.format(Fk:translate("$RemoveObserver"), p.player:getScreenName()))
      break
    end
  end
end

function ClientBase:switchToObserver(data)
  -- 将玩家和旁观数据也修改一下再给qml
  local id = data[1]
  local lp = self:getPlayerById(id)
  local cp = lp.player --[[@as fk.Player]]
  local _id, _name, _avatar, _gameTime = cp:getId(), cp:getScreenName(), cp:getAvatar(), cp:getTotalGameTime()
  local player = {
    getId = function() return _id end,
    getScreenName = function() return _name end,
    getAvatar = function() return _avatar end,
    getState = function() return fk.Player_Online end,
    getTotalGameTime = function() return _gameTime end,
  }
  table.removeOne(self.players, lp)
  -- FIXME: Self不能死 不是这哪来那么多乱七八糟的耦合
  if id ~= Self.id then
    self.client:removePlayer(id)
  end
  table.insert(self.observers, { 0, player, id })
end

function ClientBase:switchToPlayer(data)
  local id = data[1]
  local p
  for i, t in ipairs(self.observers) do
    if t[3] == id then
      p = t[2]
      table.remove(self.observers, i)
      break
    end
  end

  if not p then return end

  local cp = self.client:addPlayer(p:getId(), p:getScreenName(), p:getAvatar())
  cp:addTotalGameTime(p:getTotalGameTime())
  local lp = self:createPlayer(cp)
  -- FIXME: 呃，这都哪跟哪，client的c++代码急须重构啊
  -- v0.6 救救我们
  if p:getId() == Self.id then
    self.client:changeSelf(p:getId())
    Self = lp
  end
  table.insert(self.players, lp)
end

function ClientBase.filterChatMessage(msg)
  if type(msg) ~= "string" or msg == "" then return nil end

  if msg:find("<[%a/!][^>]*>") then
    return nil
  end

  local banwords = (ServerConfig and ServerConfig.banwords)
      or (Fk and Fk.currentClientConfig and Fk.currentClientConfig.banwords)
      or {}
  for _, word in ipairs(banwords) do
    if type(word) == "string" and word ~= "" then
      local plain_word = word:gsub("[%(%)%.%%%+%-%*%?%[%^%$]", "%%%1")
      msg = msg:gsub(plain_word, function()
        local mask = ""
        for _ in utf8.codes(word) do
          mask = mask .. "*"
        end
        return mask
      end)
    end
  end

  return msg
end

function ClientBase:chat(data)
  -- jsonData: { int type, int sender, string msg }
  if data.type == 1 then
    if data.msg then
      local filtered = ClientBase.filterChatMessage(data.msg)
      if not filtered then return end
      data.msg = filtered
    end
    data.general = ""
    data.time = os.date("%H:%M:%S")
    self:notifyUI("Chat", data)
    return
  end

  if data.msg then
    local filtered = ClientBase.filterChatMessage(data.msg)
    if not filtered then return end
    data.msg = filtered
  end

  local p = self:getPlayerById(data.sender)
  if not p then
    for _, pl in ipairs(self.observers) do
      if pl[3] == data.sender then
        p = { player = pl[2] }; break
      end
    end
    if not p then return end
    data.general = ""
  else
    data.general = p.general
  end
  if data.general == nil then
    data.general = ""
  end
  if data.general == "" and self:getPlayerById(data.sender) ~= nil then
    data.general = p.player:getAvatar()
  end
  data.userName = p.player:getScreenName()
  data.time = os.date("%H:%M:%S")
  self:notifyUI("Chat", data)
end

function ClientBase:arrangeSeats(player_circle)
  local n = #self.players
  local players = {}

  for i = 1, n do
    local p = self:getPlayerById(player_circle[i])
    p.seat = i
    table.insert(players, p)
  end

  for i = 1, #players - 1 do
    players[i].next = players[i + 1]
  end
  players[#players].next = players[1]

  self.players = players

  self:notifyUI("ArrangeSeats", player_circle)
end

function ClientBase:handleSetPlayerMark(data)
  -- jsonData: [ int id, string mark, int value ]
  local player, mark, value = data[1], data[2], data[3]
  local p = self:getPlayerById(player)
  p:setMark(mark, value)

  if string.sub(mark, 1, 1) == "@" then
    if mark:startsWith("@[") and mark:find(']') then
      local close = mark:find(']')
      local mtype = mark:sub(3, close - 1)
      local spec = Fk.qml_marks[mtype]
      if spec then
        local text = spec.how_to_show(mark, value, p)
        if text == "#hidden" then data[3] = 0 end
      end
    end
    self:notifyUI("SetPlayerMark", data)
  end
end

function ClientBase:handleSetBanner(data)
  -- jsonData: [ int id, string mark, int value ]
  local mark, value = data[1], data[2]
  self:setBanner(mark, value)

  if string.sub(mark, 1, 1) == "@" then
    self:notifyUI("SetBanner", data)
  end
end

function ClientBase:sendDataToUI(data)
  for k, v in pairs(self.banners) do
    if k[1] == "@" then
      self:notifyUI("SetBanner", { k, v })
    end
  end
end

function ClientBase:loadRoomSummary(data)
  local enter_room_data = { #data.circle, data.timeout, data.settings }
  self:enterRoom(enter_room_data)
  -- enterRoom会换掉client，重新赋值！
  self = ClientInstance --[[@as ClientBase]]
  self:notifyUI("EnterRoom", enter_room_data)

  local players = data.players

  for _, pid in ipairs(data.circle) do
    if pid ~= data.you then
      self:addPlayer(players[pid].setup_data)
    end
  end

  local observers = data.observers
  for _, t in ipairs(observers) do
    self:addObserver(t)
  end

  self:startGame(nil, data.played_time)

  self:arrangeSeats(data.circle)

  self:deserialize(data)

  -- 此处已同步全部数据 剩下就是更新UI
  -- 交给各种Client复写了
  self:sendDataToUI(data)
  for _, p in ipairs(self.players) do p:sendDataToUI() end
end

function ClientBase:reconnect(data)
  -- 旁观者自己不在房间玩家列表，断线重连走 observe 流程，不会收到自己的 Reconnect。
  -- 若正处于旁观却收到 Reconnect，那必然是被旁观者(observee)重连后转发的整房摘要：
  -- 不应把自己当成重连者整包重建，否则 room 被刷新、观察视角/切视角功能被打断。
  -- （回放录像 replaying 仍需要执行 Reconnect 片段来同步画面，故放行）
  if self.observing and not self.replaying then
    return
  end

  local players = data.players

  self:stopRecording("")
  self:notifyUI("EnterLobby", "")

  if not self.replaying then
    self:startRecording()
    self.record[6] = "reconnect"
    table.insert(self.record, { math.floor(os.getms() / 1000), false, "Reconnect", cbor.encode(data) })
  end

  local setup_data = players[data.you].setup_data
  self:setup(setup_data)

  self:loadRoomSummary(data)

  self:addTotalGameTime { setup_data[1], setup_data[5] }
end

function ClientBase:observe(data)
  local players = data.players

  self:stopRecording("")
  -- 若我此时处于房间中则发送一下进大厅刷页面
  if table.find(self.observers, function(t)
        -- 在开战前的房间，observers里面有Self.id
        return t[3] == Self.id or
            -- 在开战后的房间，Self.id换个法子寻找
            t[3] == (self.observer_setup_data or {})[1]
      end) then
    self:notifyUI("EnterLobby", "")
  end

  if not self.replaying then
    self:startRecording()
    self.record[6] = "reconnect"
    table.insert(self.record, { math.floor(os.getms() / 1000), false, "Observe", cbor.encode(data) })
  end

  if not self.observer_setup_data then
    self.observer_setup_data = {
      Self.id, Self.player:getScreenName(), Self.player:getAvatar(),
      Self.player:getTotalGameTime() }
  end
  -- 记录本次 observee 的真实总时长：enterRoom 用它给 map[observee] 设置正确基线，
  -- 避免 UI 首次取值（EnterRoom 通知同步触发渲染）时仍拿到被污染的旁观者时长。
  local setup_data = players[data.you].setup_data
  self.observer_setup_data[5] = setup_data and setup_data[5]

  self:setup(setup_data)

  self:loadRoomSummary(data)

  -- loadRoomSummary 内部重建了 client（Self 此时为被旁观者）。
  -- 纠正被旁观者(observee)的总时长基线：
  -- setup 顶替只改了 cpp self 的 id/name/avatar，totalGameTime 仍是旁观者本人的；
  -- enterRoom 的 FIXME 段又会把这个(本人的)时长复制给 observee 的 cpp player，
  -- 而 observee 的真实总时长在 setup_data[5]（服务器 serialize 下发）。
  -- 这里用差值把 observee 的时长纠正为真实值（对照 reconnect 里的 addTotalGameTime）。
  self = ClientInstance
  local you = self:getPlayerById(data.you)
  local real_time = setup_data and setup_data[5]
  if you and real_time then
    you.player:addTotalGameTime(real_time - you.player:getTotalGameTime())
  end

  -- 在新实例上把旁观者本人注册为独立身份（observer_player：cpp player + Lua Player），
  -- 并加入旁观者列表。从此本人以独立身份常驻 cpp map，Self 仍指向被旁观者用于渲染视角；
  -- 返回房间 / 等待界面时直接 changeSelf 切回本人即可，无需再 addPlayer 覆盖顶回。
  self:ensureObserverIdentity()
end

-- 将旁观者本人注册为独立身份（cpp player + Lua Player + 旁观者列表条目）。
-- 本人 player 以本人 id 常驻 cpp players map，不再被覆盖或泄漏。
-- @return ClientPlayer? 本人对应的 Lua Player；非旁观状态时返回 nil
function ClientBase:ensureObserverIdentity()
  if self.observer_player then
    return self.observer_player
  end
  local t = self.observer_setup_data
  if not t then
    return nil
  end
  local cp = self.client:addPlayer(t[1], t[2], t[3])
  if t[4] then
    cp:addTotalGameTime(t[4])
  end
  local lp = self:createPlayer(cp)
  self.observer_player = lp
  self.observers = self.observers or {}
  -- 防重：开战前旁观时 EnterRoom 的 _observers 已含本人，进入对局后再调用本函数
  -- 不能重复插入本人。同一 id 只保留一条并升级为真实 cp（供 ResetClientLua 切回本人）。
  local inserted = false
  for i = #self.observers, 1, -1 do
    local o = self.observers[i]
    if o[3] == t[1] then
      if inserted then
        table.remove(self.observers, i)
      else
        self.observers[i] = { 0, cp, t[1] }
        inserted = true
      end
    end
  end
  if not inserted then
    table.insert(self.observers, { 0, cp, t[1] })
  end
  return lp
end

function ClientBase:setPlayerProperty(player, property, value)
  player[property] = value
end

function ClientBase:propertyUpdate(data)
  -- jsonData: [ int id, string property_name, value ]
  local id, name, value = data[1], data[2], data[3]
  local p = self:getPlayerById(id)
  if not p then return end
  self:setPlayerProperty(p, name, value)
  self:notifyUI("PropertyUpdate", data)
end

-- TODO 想想办法啊
function ClientBase:parseMsg(msg, nocolor)
  local data = msg
  local function parseArg(arg)
    arg = arg or ""
    arg = Fk:translate(arg)
    arg = string.format('<font color="%s"><b>%s</b></font>', nocolor and "white" or "#0598BC", arg)
    return arg
  end

  local log = Fk:translate(data.type)

  for i = 2, 9 do
    local v = data["arg" .. i]
    if v == nil then break end
    local arg = parseArg(v)
    log = log:gsub("%%arg" .. i, arg)
  end
  local arg = parseArg(data.arg)
  log = log:gsub("%%arg", arg)

  return log
end

function ClientBase:appendLog(msg)
  local text = self:parseMsg(msg, nil)
  self:notifyUI("GameLog", text)
  if msg.toast then
    self:notifyUI("ShowToast", text)
  end
end

function ClientBase:addNpc(data)
  local id, name, avatar, ready, time = data[1], data[2], data[3], data[4], data[5]
  local player = self.client:addPlayer(id, name, avatar)
  player:addTotalGameTime(time or 0)
  -- cpp连这个都没做？
  if id > 0 then
    player:setState(fk.Player_Online)
  else
    player:setState(fk.Player_Robot)
  end
  local p = self:createPlayer(player)
  p.ready = ready
  table.insert(self.players, p)
  self:notifyUI("AddNpc", data)
end

function ClientBase:gameOver(jsonData)
  if self.recording then
    self:stopRecording(jsonData)
    if not self.observing and not self.replaying then
      local result
      local winner = jsonData
      if table.contains(winner:split("+"), tostring(Self.id)) then
        result = 1
      elseif winner == "" then
        result = 3
      else
        result = 2
      end
      self.client:saveGameData(self:getSettings('gameMode'), Self.general or "",
        Self.deputyGeneral or "", Self.role or "", result, self.record[2],
        cbor.encode(self:serialize()), cbor.encode(self.record))
    end
  end
  Self.buddy_list = table.map(self.players, Util.IdMapper)
  self.gameStarted = false
  self:notifyUI("GameOver", jsonData)
end

function ClientBase:serialize()
  local klass = self.class.super --[[@as Base.RoomBase]]
  local o = klass.serialize(self)
  o.you = Self.id
  return o
end

return ClientBase
