--- 各种ServerPlayer的第二基类
---@class ServerPlayerBase : Base.Player
---@field public serverplayer fk.ServerPlayer @ 控制者对应的C++玩家
---@field public _splayer fk.ServerPlayer @ 对应的C++玩家
---@field public room ServerRoomBase
---@field public _timewaste_count integer @连续烧绳时间，单位为秒
---@field public ai Base.AI
local ServerPlayerBase = {}

function ServerPlayerBase:initialize(_self)
  self.serverplayer = _self   -- 控制者
  self._splayer = _self       -- 真正在玩的玩家
  self._observers = { _self } -- "旁观"中的玩家，然而不包括真正的旁观者
  self.id = _self:getId()

  self._timewaste_count = 0
end

function ServerPlayerBase.filterChatMessage(msg)
  if type(msg) ~= "string" or msg == "" then return nil end

  if msg:find("<[%a/!][^>]*>") then
    return nil
  end

  local banwords = ServerConfig and ServerConfig.banwords or {}
  for _, word in ipairs(banwords) do
    if type(word) == "string" and word ~= "" then
      local plain_word = word:gsub("[%(%)%.%%%+%-%*%?%[%^%$]", "%%%1")
      msg = msg:gsub(plain_word, function()
        local mask = ""
        for _ in utf8.codes(word) do
          mask = mask .. "*"
        end
        return mask
      end)
    end
  end

  return msg
end

Fk.filterChatMessage = ServerPlayerBase.filterChatMessage

---@param command string
---@param data any
function ServerPlayerBase:doNotify(command, data)
  if command == "Chat" and type(data) == "table" and data.msg then
    local filtered = ServerPlayerBase.filterChatMessage(data.msg)
    if not filtered then return end
    data.msg = filtered
  end

  local room = self.room
  -- TQS_HEG_CARD_WIRE_DISPATCH: the next protocol is opt-in until both the
  -- native projector and Lua client implement stable per-socket aliases.
  -- If enabled, never silently fall back to one shared unprojected CBOR.
  assert(room.card_wire_version == nil or room.card_wire_version == 1,
    "unsupported card wire protocol version")
  local privateWire = room.card_wire_version == 1
  if privateWire then
    assert(room:getSettings("gameMode") == "new_heg_mode" and
      type(room.projectCardWire) == "function",
      "card wire v1 requires a new_heg_mode per-socket projector")
    assert(command ~= "Reconnect",
      "card wire v1 Reconnect must target the actual physical socket")
  end
  local cbordata = not privateWire and cbor.encode(data) or nil

  -- Preflight every physical payload before sending the first packet. A
  -- projector/CBOR failure for a late spectator must not half-deliver an event.
  local pending = {}
  local batch
  if privateWire then
    assert(type(room.beginCardWireBatch) == "function",
      "card wire v1 requires transaction support")
    batch = room:beginCardWireBatch()
    assert(type(batch) == "table" and type(batch.commit) == "function" and
      type(batch.abort) == "function",
      "card wire v1 requires a commit/abort batch")
  end
  local function stagePhysical(physical, counted)
    if physical:getState() == fk.Player_Robot then return end
    local payload = cbordata
    if privateWire then
      local projected = room:projectCardWire(self, physical, command, data, batch)
      assert(projected ~= nil,
        "card wire v1 projector must return a physical-recipient payload")
      payload = cbor.encode(projected)
    end
    pending[#pending + 1] = { physical = physical, payload = payload, counted = counted }
  end

  local ok, failure = pcall(function()
    for _, p in ipairs(self._observers) do stagePhysical(p, true) end

    for _, t in ipairs(room.observers) do
      local id, p = table.unpack(t)
      -- Spectator handles are independent of the watched seat's handles.
      if id == self.id and command ~= "Reconnect" and room.room:hasObserver(p) then
        stagePhysical(p, false)
      end
    end
  end)
  if not ok then
    if batch then batch:abort() end
    error(failure)
  end
  if batch then batch:commit() end

  for _, item in ipairs(pending) do
    if item.counted then room.notify_count = room.notify_count + 1 end
    item.physical:doNotify(command, item.payload)
  end

  if room.notify_count >= room.notify_max and
      coroutine.status(room.main_co) == "normal" then
    room:delay(100)
  end
end

function ServerPlayerBase:doNotifyToPhysical(command, data, physical)
  local room = self.room
  assert(command == "Reconnect" and room.card_wire_version == 1 and
    room:getSettings("gameMode") == "new_heg_mode" and
    type(room.projectCardWire) == "function" and
    physical == self._splayer and table.contains(self._observers, physical),
    "card wire v1 Reconnect requires the returning physical socket")
  if physical:getState() == fk.Player_Robot then return end
  assert(type(room.beginCardWireBatch) == "function",
    "card wire v1 Reconnect requires transaction support")
  local batch = room:beginCardWireBatch()
  assert(type(batch) == "table" and type(batch.commit) == "function" and
    type(batch.abort) == "function", "card wire v1 requires commit/abort")
  local ok, payload, negotiation = pcall(function()
    local projected = room:projectCardWire(self, physical, command, data, batch)
    assert(projected ~= nil, "card wire v1 Reconnect requires a physical payload")
    return cbor.encode(projected), cbor.encode {
      protocol = "TQS_HEG_CARD_WIRE", cardWireVersion = 1, mode = "new_heg_mode",
    }
  end)
  if not ok then
    batch:abort()
    error(payload)
  end
  batch:commit()
  -- Reconnect must also work in a fresh browser, without prior Lua state.
  physical:doNotify("CardWireNegotiated", negotiation)
  physical:doNotify(command, payload)
  room.notify_count = room.notify_count + 1
  if room.notify_count >= room.notify_max and
      coroutine.status(room.main_co) == "normal" then
    room:delay(100)
  end
end

--- 发送一句聊天
---@param msg string
function ServerPlayerBase:chat(msg)
  local filtered = ServerPlayerBase.filterChatMessage(msg)
  if not filtered then return end
  self.room:doBroadcastNotify("Chat", {
    type = 2,
    sender = self.id,
    msg = filtered,
  })
end

function ServerPlayerBase:reconnect()
  local room = self.room

  local sp = self._splayer
  local summary = room:serialize(self)

  -- 可能断线时在别人视角思考；先找到正在思考的视角
  local thinker = table.find(room.players, function(p)
    return table.contains(p._observers, sp)
  end)
  ---@cast thinker -nil

  -- 然后将视角设为自己 因为刚刚重连嘛
  table.removeOne(thinker._observers, sp)
  table.insert(self._observers, sp)

  -- 至此方可正常用doNotify
  if room.card_wire_version == 1 then
    self:doNotifyToPhysical("Reconnect", summary, sp)
  else
    self:doNotify("Reconnect", summary)
  end
  self:doNotify("RoomOwner", { room.room:getOwner():getId() })

  room:broadcastProperty(self, "state")

  -- 如果是直接顶号的话，部分情况Request会继续执行但是客户端没有交互信息
  -- 所以如果有这种情况的话，再发送一次给重连的玩家
  local req = room.current_request
  if req and table.contains(req.players, thinker) and
      sp:thinking() and not req.result[thinker.id] then
    sp:setThinking(false)
    req:_sendPacket(thinker)
  end
end

function ServerPlayerBase:serialize()
  local klass = self.class.super --[[@as Base.Player]]
  local o = klass.serialize(self)
  local sp = self._splayer
  local game_data = {}
  for _, value in fk.qlist(sp:getGameData()) do
    table.insert(game_data, value)
  end
  o.setup_data = {
    self.id,
    sp:getScreenName(),
    sp:getAvatar(),
    false,
    sp:getTotalGameTime(),
    game_data,
  }
  return o
end

--- 保存当前游戏模式的玩家存档
---@param data table
function ServerPlayerBase:saveState(data)
  if not self._splayer then return nil end
  if type(self._splayer.saveState) ~= "function" then
    fk.qWarning("self._splayer.saveState doesn't exist, Please ensure that the server version is freekill-asio 0.0.5+")
    return nil
  end
  local ok, jsonData = pcall(json.encode, data)
  if ok then
    local ret = self._splayer:saveState(jsonData)
    if type(ret) == "boolean" then
      self.room:yield(function(r) return r == "query_done" end)
    end
  else
    fk.qWarning("Failed to encode save data: " .. jsonData)
  end
end

--- 获取当前游戏模式的玩家存档
---@return table @ 不存在返回空表
function ServerPlayerBase:getSaveState()
  if not self._splayer then return {} end
  if type(self._splayer.getSaveState) ~= "function" then
    fk.qWarning(
      "self._splayer.getSaveState doesn't exist, Please ensure that the server version is freekill-asio 0.0.5+")
    return {}
  end
  local data = self._splayer:getSaveState()
  if type(data) == "boolean" then
    data = self.room:yield(function(reason)
      local ok = pcall(json.decode, reason)
      return ok
    end)
  end
  local ok, result = pcall(json.decode, data or "{}")
  if ok then
    return result
  else
    fk.qWarning("Failed to decode save data: " .. result)
    return {}
  end
end

--- 全局存档
---@param key string 存档名
---@param data table
function ServerPlayerBase:saveGlobalState(key, data)
  if not self._splayer then return nil end
  if type(self._splayer.saveGlobalState) ~= "function" then
    fk.qWarning(
      "self._splayer.saveGlobalState doesn't exist, Please ensure that the server version is freekill-asio 0.0.6+")
    return nil
  end
  local ok, jsonData = pcall(json.encode, data)
  if ok then
    local ret = self._splayer:saveGlobalState(key, jsonData)
    if type(ret) == "boolean" then
      self.room:yield(function(r) return r == "query_done" end)
    end
  else
    fk.qWarning("Failed to encode global save data: " .. jsonData)
  end
end

--- 获取全局存档
---@param key string 存档名
---@return table @ 不存在返回空表
function ServerPlayerBase:getGlobalSaveState(key)
  if not self._splayer then return {} end
  if type(self._splayer.getGlobalSaveState) ~= "function" then
    fk.qWarning(
      "self._splayer.getGlobalSaveState doesn't exist, Please ensure that the server version is freekill-asio 0.0.6+")
    return {}
  end
  local data = self._splayer:getGlobalSaveState(key)
  if type(data) == "boolean" then
    data = self.room:yield(function(reason)
      local ok = pcall(json.decode, reason)
      return ok
    end)
  end
  local ok, result = pcall(json.decode, data or "{}")
  if ok then
    return result
  else
    fk.qWarning("Failed to decode global save data: " .. result)
    return {}
  end
end

return ServerPlayerBase
