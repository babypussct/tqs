local hujia = fk.CreateSkill {
  name = "hujia",
  tags = { Skill.Lord },
}

local spec = {
  anim_type = "defensive",
  can_trigger = function(self, event, target, player, data)
    return target == player and player:hasSkill(hujia.name) and
        Exppattern:Parse(data.pattern):matchExp("jink") and
        (data.extraData == {} or (data.extraData.hujia_ask == nil and data.extraData.not_passive ~= true)) and
        not table.every(player.room.alive_players, function(p)
          return p == player or p.kingdom ~= "wei"
        end)
  end,
  on_use = function(self, event, target, player, data)
    local room = player.room
    for _, p in ipairs(room:getOtherPlayers(player)) do
      if p:isAlive() and p.kingdom == "wei" then
        local params = { ---@type AskToUseCardParams
          skill_name = "jink",
          pattern = "jink",
          prompt = "#hujia-ask:" .. player.id,
          cancelable = true,
          extra_data = { hujia_ask = true }
        }
        local respond = room:askToResponse(p, params)
        if respond then
          respond.skipDrop = true
          room:responseCard(respond)
          if not respond.nullified then
            local new_card = Fk:cloneCard('jink')
            new_card.skillName = hujia.name
            new_card:addSubcards(room:getSubcardsByRule(respond.card, { Card.Processing }))
            local result = {
              from = player,
              card = new_card,
            }
            if event == fk.AskForCardUse then
              result.tos = {}
            end
            data.result = result
            return true
          else
            room:moveCards({
              ids = room:getSubcardsByRule(respond.card, { Card.Processing }),
              toArea = Card.DiscardPile,
              moveReason = fk.ReasonResponse,
            })
          end
        end
      end
    end
  end,
}

hujia:addEffect(fk.AskForCardUse, spec)
hujia:addEffect(fk.AskForCardResponse, spec)

hujia:addAI(Fk.Ltk.AI.newInvokeStrategy {
  think = function(self, ai)
    for _, p in ipairs(ai.player.room.alive_players) do
      if ai:isFriend(p) and p.kingdom == "wei" and
        (p:hasSkill("#eight_diagram_skill") or
        #table.filter(ai.player:getHandlyIds(), function(cid)
          return Fk:getCardById(cid).trueName == "jink"
        end) <= 1) then
        return true
      end
    end
    return false
  end,
})

return hujia
