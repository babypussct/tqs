local skill = fk.CreateSkill {
  name = "duel_skill",
}

skill:addEffect("cardskill", {
  prompt = "#duel_skill",
  mod_target_filter = function(self, player, to_select, selected, card)
    return to_select ~= player
  end,
  target_filter = Util.CardTargetFilter,
  target_num = 1,
  on_effect = function(self, room, effect)
    local to = effect.to
    local from = effect.from
    local responsers = { to, from }
    local currentTurn = 1
    local currentResponser = to

    while currentResponser:isAlive() do
      local loopTimes = effect:getResponseTimes(currentResponser)

      local respond
      for i = 1, loopTimes do
        local params = { ---@type AskToUseCardParams
          skill_name = 'slash',
          pattern = 'slash',
          cancelable = true,
          event_data = effect
        }
        if loopTimes > 1 then
          params.prompt = "#AskForResponseMultiCard:::slash:"..i..":"..loopTimes
        end
        respond = room:askToResponse(currentResponser, params)
        if respond then
          room:responseCard(respond)
        end
        if not (respond and not respond.nullified) then
          break
        end
      end

      if not (respond and not respond.nullified) then
        break
      end

      currentTurn = currentTurn % 2 + 1
      currentResponser = responsers[currentTurn]
    end

    if currentResponser:isAlive() then
      room:damage({
        from = responsers[currentTurn % 2 + 1],
        to = currentResponser,
        card = effect.card,
        damage = 1,
        damageType = fk.NormalDamage,
        skillName = skill.name,
      })
    end
  end,
})

skill:addAI(Fk.Ltk.AI.newCardSkillStrategy {
  keep_value = 3.42,
  use_value = 3.7,
  use_priority = 2.9,

  on_effect = function(self, logic, effect)
    local nums = table.map({ effect.from, effect.to }, function (p)
      return #table.filter(p:getHandlyIds(), function (id)
        return Fk:getCardById(id).trueName == "slash" and not p:prohibitResponse(Fk:getCardById(id))
      end)
    end)
    logic:damage({
      from = nums[1] >= nums[2] and effect.from or effect.to,
      to = nums[1] >= nums[2] and effect.to or effect.from,
      card = effect.card,
      damage = 1,
      damageType = fk.NormalDamage,
      skillName = skill.name,
    })
  end,
})

return skill
