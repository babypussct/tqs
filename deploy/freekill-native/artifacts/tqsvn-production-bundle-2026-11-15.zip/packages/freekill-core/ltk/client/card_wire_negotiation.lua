-- Candidate-only card-wire v1 negotiation.
--
-- The server sends this envelope on the legacy notification path before it
-- changes the room projection mode. It intentionally contains no card,
-- player-private or ordering data. A malformed or downgraded envelope is
-- rejected before any v1 decoder can run.
local Negotiation = {}

local allowedFields = {
  protocol = true,
  cardWireVersion = true,
  mode = true,
}

function Negotiation.receive(client, data)
  assert(type(data) == "table", "card wire negotiation must be a map")
  for key in pairs(data) do
    assert(allowedFields[key] == true,
      "card wire negotiation contains an unaudited field")
  end
  assert(data.protocol == "TQS_HEG_CARD_WIRE",
    "unsupported card wire negotiation protocol")
  assert(data.cardWireVersion == 1,
    "unsupported card wire negotiation version")
  assert(data.mode == "new_heg_mode",
    "card wire negotiation is restricted to Hegemony")
  assert(client.card_wire_version == nil or client.card_wire_version == 1,
    "card wire client cannot downgrade its negotiated version")

  client.card_wire_version = 1
  client.card_wire_protocol = data.protocol
  client.card_wire_negotiated = true
  return true
end

return Negotiation
