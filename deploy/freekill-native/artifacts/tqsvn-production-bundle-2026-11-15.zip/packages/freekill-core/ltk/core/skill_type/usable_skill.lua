-- SPDX-License-Identifier: GPL-3.0-or-later

--[[
  此为可发动技能。

  技能发动时，会产生SkillEffect事件，负责技能的计数，以及实际执行效果等。
--]]

---@class UsableSkill : Skill
---@field public max_use_time table<integer, integer?> @ 一个效果的最大可用次数
---@field public history_branch? string | fun(self: UsableSkill, player: ServerPlayer, data: SkillUseData, extra_data?: UseExtraData|table):string? @ 发动时是否将技能发动历史归类到某个分支
---@field public times? fun(self: UsableSkill, player: Player): integer
local UsableSkill = Skill:subclass("UsableSkill")

function UsableSkill:initialize(name, frequency)
  frequency = frequency or Skill.NotFrequent
  Skill.initialize(self, name, frequency)

  self.max_use_time = { nil, nil, nil, nil }
end

-- 获得技能的最大使用次数
---@param player Player @ 使用者
---@param scope? integer @ 查询历史范围（默认为回合）
---@param card? Card @ 卡牌
---@param to? Player @ 目标
---@return number? @ 最大使用次数，nil就是无限
function UsableSkill:getMaxUseTime(player, scope, card, to)
  scope = scope or Player.HistoryTurn
  local time = self.max_use_time[scope]
  local ret = time
  if type(time) == "function" then
    ret = time(self, player)
  end
  if not ret then return nil end
  if card then
    local status_skills = Fk:currentRoom().status_skills[TargetModSkill] or Util.DummyTable
    for _, skill in ipairs(status_skills) do
      local fix = skill:getFixedNum(player, self, scope, card, to)
      if fix ~= nil then -- 典中典之先到先得
        ret = fix
        break
      end
      local correct = skill:getResidueNum(player, self, scope, card, to)
      if correct == nil then correct = 0 end
      ret = ret + correct
    end
  end
  return ret
end

-- 判断一个角色是否在技能的次数限制内
---@param player Player @ 使用者
---@param scope? integer @ 查询历史范围（默认为回合）
---@param card? Card @ 牌，若没有牌，则尝试制造一张虚拟牌
---@param card_name? string @ 牌名
---@param to? Player @ 目标
---@return boolean?
function UsableSkill:withinTimesLimit(player, scope, card, card_name, to)
  if to and to.dead then return false end -- 一般情况不会对死人使用技能的……
  scope = scope or Player.HistoryTurn
  local status_skills = Fk:currentRoom().status_skills[TargetModSkill] or Util.DummyTable
  if not card then
    if card_name then
      card = Fk:cloneCard(card_name)
    elseif self.name:endsWith("_skill") then
      card = Fk:cloneCard(self.name:sub(1, #self.name - 6))
    end
  end

  local limit = self:getMaxUseTime(player, scope, card, to)
  if not limit then return true end

  if not card_name then
    if card then
      card_name = card.trueName
    else ---坏了，不是卡的技能
      return player:usedEffectTimes(self.name, scope) < limit
    end
  end

  for _, skill in ipairs(status_skills) do
    if skill:bypassTimesCheck(player, self, scope, card, to) then return true end
  end

  return player:usedCardTimes(card_name, scope) < limit or
  (card and not not card:hasMark(MarkEnum.BypassTimesLimit)) or
  not not player:hasMark(MarkEnum.BypassTimesLimit) or
  (to and not not to:hasMark(MarkEnum.BypassTimesLimitTo))
end

return UsableSkill
